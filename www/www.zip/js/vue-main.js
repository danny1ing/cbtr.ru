/*var change_password = new Vue({
  el: '#change_password',
  data: {
    profile_password: false,
    profile_password_a: true
  },
  methods: {
  	view_change_password: function() {
  		this.profile_password: true,
  		this.profile_password_a: false,
  		console.log('че то там')
  	}
  }
})*/
var change_password = new Vue({
            el: "#change_password",
            data: {
                profile_password: false,
                profile_password_a: true
            },
            methods: {
                prof_pass: function() {
                    this.profile_password = true,
                    this.profile_password_a = false
                }
            }
        })

