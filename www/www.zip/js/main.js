$(document).ready(function(){
    $(".close-offcanvas").click(function(){
        $('.navmenu.offcanvas').offcanvas('hide');
        return false;
    });
    
    window.addEventListener('scroll', function(e) {
        if (window.pageYOffset >= ($("body").offset().top + 100)) {
            $("header").addClass("sticky");
            $("body").css("padding-top","75px");
        }
        else {
            $("header").removeClass("sticky");
            $("body").css("padding-top","0");
        }
        if (window.pageYOffset >= ($("body").offset().top + 200) && window.pageYOffset < ($("footer").offset().top - 1000)) {
            $(".top").fadeIn();
            $(".article .info-panel").css("position","fixed").css("bottom","20px").fadeIn();
        }
        else if(window.pageYOffset >= ($("footer").offset().top - 1000)){
            $(".article .info-panel").css("position","absolute").css("bottom","65px");        
        }
        else {
            $(".top").fadeOut();
            $(".article .info-panel").fadeOut();
        }
    });
    
    $(".base-service h4, .base-way-point h4").click(function(){
       if($(this).hasClass("active")){
           $(this).removeClass("active");
           $(this).siblings("div:not(.decor)").slideUp();
       } 
       else {
            $(this).addClass("active");
            $(this).siblings("div:not(.decor)").slideDown();
       }
        
        return false;
    });
    
    $('.top').click(function (){
        $('html, body').animate({
            scrollTop: 0
        }, 1000);
        return false;
    });
    
    $(".catalog-category").click(function(){
        if(!$(this).hasClass("active")){
            $(".catalog-category").removeClass("active");
            $(this).addClass("active");
            var ind = $(".catalog-category").index($(this));
            $(".catalog-category .tr").hide();
            $(".catalog-category-companies").hide();
            $(".catalog-xs-container").hide();

            $(this).find(".tr").show();

            if($(window).width() < 468){
                if ( ind & 1 ) {
                    var ind2 = (ind - 1) / 2;
                } 
                else {
                    var ind2 = ind / 2;
                }
                $(".catalog-xs-container").html("");
                var htmlValue = $(".catalog-category-companies:eq("+ind+")").html();
                $(".catalog-xs-container:eq("+ind2+")").html('<div class="container">' + htmlValue + '</div>');
                $(".catalog-xs-container:eq("+ind2+")").slideDown(); 
            }
            else {
                $(".catalog-category-companies:eq("+ind+")").slideDown();    
            }
        }
        else {
            $(".catalog-category").removeClass("active");
            $(".catalog-category-companies").slideUp("fast",
                function(){
                    $(".catalog-category .tr").hide();
                }
            );
            $(".catalog-xs-container").slideUp("fast",
                function(){
                    $(".catalog-category .tr").hide();
                }
            );
        }
        
        return false;
    });
    
    $(".video-overlay a").click(function(){
        $(this).parent(".video-overlay").hide();
        
        return false;
    });
    
    $(".menu-item-has-children").click(function(){
        if(!$(this).hasClass("active")){
            $(".menu-item-has-children").removeClass("active");
            $(this).addClass("active");
            $(".sub-menu").slideUp();
            $(this).find(".sub-menu").slideDown();
        }
        else {
            $(this).removeClass("active");
            $(".sub-menu").slideUp();
        }
        
        return false;
    });
    
    $('.base-way').slick({
        dots: false,
        infinite: false,
        speed: 300,
        slidesToShow: 4,
        slidesToScroll: 1,
        responsive: [
            {
              breakpoint: 992,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1
              }
            },
            {
              breakpoint: 768,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            }
        ]
    });
    
    $('#education-slider').slick({
        dots: false,
        arrows: true,
        prevArrow: '.prev',
        nextArrow: '.next',
        infinite: true,
        speed: 300,
        slidesToShow: 1,
        slidesToScroll: 1,
        centerMode: true,
        centerPadding: '10%',
        responsive: [
        {
          breakpoint: 768,
          settings: {
            arrows: false,
            centerMode: false,
            slidesToShow: 1
          }
        }
      ]
    });
    
    $('.article-slider').slick({
        dots: true,
        arrows: false,
        infinite: false,
        speed: 300,
        slidesToShow: 1,
        slidesToScroll: 1
    });
    
    if($(window).width() < 768){
        var direction = 'bottom';
    }
    else {
        var direction = 'right';
    }
    
    $('.popover-a').popover({
        html: true,
        placement: direction,
        trigger: "hover",
        content: $(this).attr("data-content")
    });
    
    $('.selectpicker').selectpicker({
      style: 'btn-info',
      size: 4
    });

});