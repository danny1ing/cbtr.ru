<?php
    include('class.fileuploader.php');
	
    // initialize the FileUploader
    $FileUploader = new FileUploader('files', array(
        // Options will go here
    ));
	
    // call to upload the files
    $upload = $FileUploader->upload();
	
    if($upload['isSuccess']) {
        // get the uploaded files
        $files = $upload['files'];
    }
    if($upload['hasWarnings']) {
        // get the warnings
        $warnings = $upload['warnings'];
    };
?>